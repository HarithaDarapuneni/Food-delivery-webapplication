from django.apps import AppConfig


class FoodorderappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'foodorderapp'
